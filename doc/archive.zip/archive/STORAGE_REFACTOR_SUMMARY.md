# 存储逻辑重构总结

## 修改日期
2025-11-11

## 修改目标

根据设计要求，重构Prompt和Template的存储逻辑，确保：

1. **YAML文件**：存储**完整元数据**（title、description、labels、author等）
2. **Markdown Front Matter**：**仅存储最小必要信息**：
   - `id` - 唯一标识符
   - `created_at` - 创建时间
   - `created_by` - 创建者
   - `variables` - 可变变量（仅Template）

3. **ChatHistory**：保持不变，按OpenAI API格式存储

---

## 修改内容

### 1. 修改文件列表

#### 1.1 核心存储服务
**文件：** [apps/core/services/file_storage_service.py](apps/core/services/file_storage_service.py)

**修改的方法：**

##### a) `create_item()` - 第98-149行

**修改前：**
```python
# Write version file (frontmatter + content)
frontmatter = f"---\n{json.dumps(metadata, indent=2, ensure_ascii=False)}\n---\n\n"
version_path.write_text(frontmatter + content, encoding='utf-8')

# Write metadata YAML
yaml_path = item_dir / f"{item_type}.yaml"
self._write_yaml(yaml_path, metadata)
```

**修改后：**
```python
# Build minimal frontmatter for version file
# Only store: id, created_at, created_by, and variables (for templates)
minimal_frontmatter = {
    'id': item_id,
    'created_at': metadata.get('created_at'),
    'created_by': metadata.get('author', metadata.get('created_by', '')),
}

# Add variables for templates
if item_type == 'template' and 'variables' in metadata:
    minimal_frontmatter['variables'] = metadata.get('variables', [])

# Write version file (minimal frontmatter + content)
frontmatter = f"---\n{json.dumps(minimal_frontmatter, indent=2, ensure_ascii=False)}\n---\n\n"
version_path.write_text(frontmatter + content, encoding='utf-8')

# Write full metadata to YAML
yaml_path = item_dir / f"{item_type}.yaml"
self._write_yaml(yaml_path, metadata)
```

**关键变化：**
- Markdown Front Matter只存储最小信息
- Template的variables字段包含在Front Matter中（版本特定）
- YAML文件存储完整元数据

---

##### b) `create_version()` - 第151-204行

**修改前：**
```python
# Write version file (immutable)
frontmatter = f"---\n{json.dumps(metadata, indent=2, ensure_ascii=False)}\n---\n\n"
version_path.write_text(frontmatter + content, encoding='utf-8')

# Update metadata YAML
yaml_path = item_dir / f"{item_type}.yaml"
metadata['updated_at'] = datetime.utcnow().isoformat()
self._write_yaml(yaml_path, metadata)
```

**修改后：**
```python
# Read existing YAML to get created_at and created_by
yaml_path = item_dir / f"{item_type}.yaml"
existing_metadata = self._read_yaml(yaml_path)

# Build minimal frontmatter for version file
minimal_frontmatter = {
    'id': item_id,
    'created_at': existing_metadata.get('created_at'),  # Keep original
    'created_by': existing_metadata.get('author', existing_metadata.get('created_by', '')),
}

# Add variables for templates (use updated metadata)
if item_type == 'template' and 'variables' in metadata:
    minimal_frontmatter['variables'] = metadata.get('variables', [])

# Write version file (immutable, minimal frontmatter)
frontmatter = f"---\n{json.dumps(minimal_frontmatter, indent=2, ensure_ascii=False)}\n---\n\n"
version_path.write_text(frontmatter + content, encoding='utf-8')

# Update metadata YAML with new data
metadata['updated_at'] = datetime.utcnow().isoformat()
self._write_yaml(yaml_path, metadata)
```

**关键变化：**
- 从现有YAML读取created_at和created_by（保持不变）
- 新版本只在Front Matter存储最小信息
- 更新的variables存储在新版本的Front Matter中

---

##### c) `read_version()` - 第206-255行

**修改前：**
```python
# Parse frontmatter
content = version_path.read_text(encoding='utf-8')
from apps.core.utils.frontmatter import parse_frontmatter
metadata, body = parse_frontmatter(content)

return metadata, body
```

**修改后：**
```python
# Read YAML metadata (contains full metadata)
yaml_path = item_dir / f"{item_type}.yaml"
yaml_metadata = self._read_yaml(yaml_path)

# ... 读取版本文件 ...

# Parse frontmatter from version file (minimal: id, created_at, created_by, variables)
content = version_path.read_text(encoding='utf-8')
from apps.core.utils.frontmatter import parse_frontmatter
version_frontmatter, body = parse_frontmatter(content)

# Merge: YAML metadata + version-specific frontmatter (variables for templates)
merged_metadata = yaml_metadata.copy()

# Override with version-specific data if present
if 'variables' in version_frontmatter:
    merged_metadata['variables'] = version_frontmatter['variables']

return merged_metadata, body
```

**关键变化：**
- 从YAML文件读取完整元数据
- 从Markdown Front Matter读取版本特定信息（variables）
- 合并两者，返回完整的元数据

---

### 2. API层无需修改

**原因：**
- API views已经通过`parse_frontmatter()`从前端接收完整元数据
- `create_item()`和`create_version()`接收完整metadata，内部自动分离存储
- `read_version()`自动合并数据，API无需感知存储细节

---

## 数据流程

### 创建Prompt/Template流程

```
前端编辑器
   ↓
发送完整Markdown（包含完整Front Matter）
   ↓
API: parse_frontmatter() 提取所有元数据
   ↓
Storage: create_item(metadata, content)
   ├─→ 写入YAML文件：完整元数据
   └─→ 写入Markdown文件：最小Front Matter + 内容
```

**示例：**

**前端发送：**
```markdown
---
title: Test Prompt
description: A test prompt
labels: [test, demo]
author: john_doe
---

# Prompt Content
This is the content.
```

**存储结果：**

1. **prompt.yaml** (完整元数据)
```yaml
id: 01K9S88PZ...
title: Test Prompt
description: A test prompt
labels:
  - test
  - demo
author: john_doe
created_at: 2025-11-11T10:00:00Z
updated_at: 2025-11-11T10:00:00Z
type: prompt
slug: test-prompt
```

2. **pv_test-prompt-01K9S88PZ..._2025-11-11T10-00Z_ABC12.md** (最小Front Matter)
```markdown
---
{
  "id": "01K9S88PZ...",
  "created_at": "2025-11-11T10:00:00Z",
  "created_by": "john_doe"
}
---

# Prompt Content
This is the content.
```

---

### 读取Prompt/Template流程

```
API: read_version(item_type, item_id, slug)
   ↓
Storage:
   1. 读取YAML文件 → 完整元数据
   2. 读取Markdown文件 → 版本内容 + 最小Front Matter
   3. 合并数据
   ↓
返回: (完整元数据, 内容)
   ↓
API: serialize_frontmatter(metadata, content)
   ↓
返回完整Markdown给前端
```

---

## Template的Variables处理

### 为什么Variables存储在Markdown Front Matter？

Template的`variables`字段是**版本特定**的：
- 不同版本可能有不同的变量定义
- 变量与版本内容紧密耦合
- 需要支持变量的版本历史

### Variables存储位置

1. **YAML文件**：存储当前（HEAD版本）的variables
2. **Markdown Front Matter**：存储该版本特定的variables

### Template创建示例

**前端发送：**
```markdown
---
title: Email Template
description: A reusable email template
labels: [email, marketing]
author: jane_doe
variables:
  - name: recipient_name
    description: Name of the recipient
    default: User
  - name: subject
    description: Email subject
    default: Welcome
---

# Hello {{recipient_name}}

Subject: {{subject}}
```

**存储结果：**

1. **template.yaml**
```yaml
id: 01K9S88PZR...
title: Email Template
description: A reusable email template
labels:
  - email
  - marketing
author: jane_doe
created_at: 2025-11-11T10:00:00Z
updated_at: 2025-11-11T10:00:00Z
type: template
slug: email-template
variables:
  - name: recipient_name
    description: Name of the recipient
    default: User
  - name: subject
    description: Email subject
    default: Welcome
```

2. **tv_email-template-01K9S88PZR..._2025-11-11T10-00Z_DQCC5.md**
```markdown
---
{
  "id": "01K9S88PZR...",
  "created_at": "2025-11-11T10:00:00Z",
  "created_by": "jane_doe",
  "variables": [
    {
      "name": "recipient_name",
      "description": "Name of the recipient",
      "default": "User"
    },
    {
      "name": "subject",
      "description": "Email subject",
      "default": "Welcome"
    }
  ]
}
---

# Hello {{recipient_name}}

Subject: {{subject}}
```

---

## 测试验证

### 测试脚本
创建了 [test_storage_logic.py](test_storage_logic.py) 进行全面测试。

### 测试结果

```
✅ Prompt Storage Test
   - YAML文件包含完整元数据 ✓
   - Markdown Front Matter只包含最小信息 ✓
   - read_version正确合并数据 ✓

✅ Template Storage Test
   - YAML文件包含完整元数据（包括variables）✓
   - Markdown Front Matter包含最小信息+variables ✓
   - read_version正确包含variables ✓
```

**运行测试：**
```bash
python test_storage_logic.py
```

---

## 架构优势

### 1. 数据分离
- **元数据**：集中在YAML，易于查询和索引
- **版本内容**：独立存储，支持版本历史

### 2. 减少冗余
- 避免在每个版本文件中重复存储相同的元数据
- 只在Front Matter存储版本特定信息

### 3. 灵活性
- 可以轻松更新元数据（只需修改YAML）
- 版本文件保持不可变（immutable）

### 4. 性能优化
- 列表查询：只读YAML文件（更小）
- 版本读取：合并YAML+Markdown
- 索引构建：从YAML读取元数据

### 5. 版本特定数据
- Template的variables可以在不同版本中变化
- 每个版本保留自己的variables定义

---

## 文件结构对比

### 修改前

```
prompts/
  └── prompt_{slug}-{id}/
      ├── prompt.yaml              # 完整元数据
      ├── HEAD
      └── versions/
          └── pv_xxx.md            # 完整Front Matter + 内容
                                   # ⚠️ 数据冗余
```

### 修改后

```
prompts/
  └── prompt_{slug}-{id}/
      ├── prompt.yaml              # 完整元数据（单一数据源）
      ├── HEAD
      └── versions/
          └── pv_xxx.md            # 最小Front Matter + 内容
                                   # ✅ 无冗余
```

---

## ChatHistory存储

**无需修改**，ChatHistory的存储逻辑保持不变：

```json
{
  "id": "01K9S88...",
  "title": "Chat Title",
  "description": "Chat description",
  "provider": "ChatGPT",
  "conversation_id": "conv-123",
  "turn_count": 5,
  "tags": ["ai", "discussion"],
  "created_at": "2025-11-11T10:00:00Z",
  "updated_at": "2025-11-11T10:30:00Z",
  "messages": [
    {
      "role": "user",
      "content": "Hello"
    },
    {
      "role": "assistant",
      "content": "Hi there!"
    }
  ]
}
```

**特点：**
- 完整的JSON文件存储
- 符合OpenAI API格式
- 自动计算turn_count
- 支持去重（基于provider + conversation_id）

---

## 向后兼容性

### 迁移旧数据

如果已有旧格式数据（Front Matter包含完整元数据），可以运行迁移脚本：

```python
# 待实现：migration_script.py
# 1. 读取旧版本文件
# 2. 提取Front Matter中的完整元数据
# 3. 写入YAML文件
# 4. 重写版本文件（只保留最小Front Matter）
```

### API兼容性

✅ **完全兼容**
- API接口未改变
- 前端无需修改
- 只是内部存储格式优化

---

## 最佳实践

### 1. 创建Prompt/Template

**前端：**
```javascript
const createPrompt = async (metadata, content) => {
  // 构建完整的frontmatter
  const fullFrontmatter = {
    title: metadata.title,
    description: metadata.description,
    labels: metadata.labels,
    author: metadata.author,
    // ... 其他元数据
  };

  const markdownContent = serialize(fullFrontmatter, content);

  await fetch('/api/v1/prompts', {
    method: 'POST',
    body: JSON.stringify({ content: markdownContent })
  });
};
```

**后端自动处理：**
- 提取所有元数据 → YAML
- 最小信息 → Markdown Front Matter

### 2. 更新Prompt/Template

**前端发送完整frontmatter**，后端自动分离存储。

### 3. 读取Prompt/Template

**后端自动合并**：
- YAML元数据
- 版本特定信息（variables）

返回完整数据给前端。

---

## 总结

### 修改内容
- ✅ 修改了3个核心方法：`create_item`、`create_version`、`read_version`
- ✅ 实现了YAML和Front Matter的数据分离
- ✅ Template的variables正确存储在版本Front Matter中
- ✅ 通过测试验证

### 影响范围
- ✅ 对API层透明（无需修改）
- ✅ 对前端透明（无需修改）
- ✅ 仅优化内部存储格式

### 优势
- ✅ 减少数据冗余
- ✅ 元数据集中管理
- ✅ 支持版本特定数据（variables）
- ✅ 提高查询性能
- ✅ 保持版本文件不可变

---

**修改人员：** Claude (Sonnet 4.5)
**修改日期：** 2025-11-11
**文档版本：** 1.0
