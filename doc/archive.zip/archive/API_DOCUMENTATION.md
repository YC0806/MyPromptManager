# API Documentation

## Base URL
```
http://localhost:8000/api/v1
```

## Data Models

### Prompt
提示词抽象对象，承载标题、分类标签（label）、描述、更新时间、最新版本等元信息。

**存储方式：**
- **元数据（YAML文件）**：存储完整元数据（title、description、labels、author等）
- **版本内容（Markdown文件）**：通过YAML Front Matter **仅存储**：
  - `id` - 唯一标识符
  - `created_at` - 创建时间
  - `created_by` - 创建者

**字段：**
- `id` (string): ULID格式的唯一标识符
- `title` (string): 标题
- `slug` (string): URL友好的标识符
- `description` (string): 描述
- `labels` (array): 分类标签数组
- `author` (string): 创建者
- `created_at` (datetime): 创建时间
- `updated_at` (datetime): 更新时间
- `type` (string): 固定值 "prompt"

### PromptTemplate
提示词模版抽象对象，承载标题、分类标签（label）、描述、更新时间、最新版本等元信息。

**存储方式：**
- **元数据（YAML文件）**：存储完整元数据（包括variables定义）
- **版本内容（Markdown文件）**：通过YAML Front Matter **仅存储**：
  - `id` - 唯一标识符
  - `created_at` - 创建时间
  - `created_by` - 创建者
  - `variables` - 可变变量（版本特定，可在不同版本中变化）

**字段：**
- `id` (string): ULID格式的唯一标识符
- `title` (string): 标题
- `slug` (string): URL友好的标识符
- `description` (string): 描述
- `labels` (array): 分类标签数组
- `author` (string): 创建者
- `created_at` (datetime): 创建时间
- `updated_at` (datetime): 更新时间
- `type` (string): 固定值 "template"
- `variables` (array): 可变变量列表
  - `name` (string): 变量名
  - `description` (string): 变量描述
  - `default` (string, optional): 默认值

### ChatHistory
用于保存从链接或浏览器插件提取的聊天记录，按OpenAI API的JSON格式messages保存。

**存储方式：**
- JSON文件 (`chat_*.json`)

**字段：**
- `id` (string): ULID格式的唯一标识符
- `title` (string): 标题
- `description` (string): 描述
- `provider` (string): 大模型提供商（如 "ChatGPT", "Claude", "Gemini"）
- `conversation_id` (string): 对话的原始ID（用于去重）
- `messages` (array): 消息数组，遵循OpenAI API格式
  - `role` (string): "user", "assistant", "system"
  - `content` (string): 消息内容
- `turn_count` (number): 对话轮次（自动计算user消息数量）
- `tags` (array): 标签数组
- `created_at` (datetime): 创建时间
- `updated_at` (datetime): 更新时间

---

## API Endpoints

### 1. Prompts

#### 1.1 List All Prompts
```http
GET /prompts
```

**Query Parameters:**
- `labels` (array, optional): 按标签筛选（支持多个，AND逻辑）
- `limit` (number, optional): 限制返回数量，默认100

**Response:**
```json
{
  "prompts": [
    {
      "id": "01HXYZ...",
      "title": "Sample Prompt",
      "slug": "sample-prompt",
      "description": "A sample prompt",
      "labels": ["demo", "test"],
      "author": "user",
      "created_at": "2024-01-01T00:00:00Z",
      "updated_at": "2024-01-02T00:00:00Z",
      "type": "prompt"
    }
  ],
  "count": 1,
  "total": 1
}
```

#### 1.2 Create New Prompt
```http
POST /prompts
```

**Request Body:**
```json
{
  "content": "---\ntitle: My Prompt\ndescription: A new prompt\nlabels: [\"test\"]\nauthor: john\n---\n\n# Prompt Content\n\nThis is the prompt body."
}
```

**Response:**
```json
{
  "id": "01HXYZ...",
  "version_id": "2024-01-01T12-00Z_abc12",
  "created_at": "2024-01-01T12:00:00Z"
}
```

#### 1.3 Get Prompt Detail
```http
GET /prompts/{id}
```

**Response:**
```json
{
  "id": "01HXYZ...",
  "metadata": {
    "id": "01HXYZ...",
    "title": "My Prompt",
    "description": "A new prompt",
    "labels": ["test"],
    "author": "john",
    "created_at": "2024-01-01T12:00:00Z",
    "updated_at": "2024-01-01T12:00:00Z",
    "type": "prompt"
  },
  "content": "# Prompt Content\n\nThis is the prompt body.",
  "full_content": "---\ntitle: My Prompt\n...\n---\n\n# Prompt Content\n..."
}
```

#### 1.4 Update Prompt (Create New Version)
```http
PUT /prompts/{id}
```

**Request Body:**
```json
{
  "content": "---\ntitle: My Updated Prompt\n...\n---\n\n# Updated Content"
}
```

**Response:**
```json
{
  "id": "01HXYZ...",
  "version_id": "2024-01-02T12-00Z_def34",
  "updated_at": "2024-01-02T12:00:00Z"
}
```

#### 1.5 Delete Prompt
```http
DELETE /prompts/{id}
```

**Response:** 204 No Content

#### 1.6 List Prompt Versions
```http
GET /prompts/{id}/versions
```

**Response:**
```json
{
  "prompt_id": "01HXYZ...",
  "versions": [
    {
      "version_id": "2024-01-02T12-00Z_def34",
      "filename": "pv_sample-prompt-01HXYZ_2024-01-02T12-00Z_def34.md",
      "created_at": "2024-01-02T12-00Z",
      "size": 1024
    },
    {
      "version_id": "2024-01-01T12-00Z_abc12",
      "filename": "pv_sample-prompt-01HXYZ_2024-01-01T12-00Z_abc12.md",
      "created_at": "2024-01-01T12-00Z",
      "size": 512
    }
  ],
  "count": 2
}
```

#### 1.7 Get Specific Version
```http
GET /prompts/{id}/versions/{version_id}
```

**Response:**
```json
{
  "prompt_id": "01HXYZ...",
  "version_id": "2024-01-01T12-00Z_abc12",
  "metadata": { ... },
  "content": "..."
}
```

---

### 2. Templates

#### 2.1 List All Templates
```http
GET /templates
```

**Query Parameters:**
- `labels` (array, optional): 按标签筛选
- `limit` (number, optional): 限制返回数量，默认100

**Response:**
```json
{
  "templates": [
    {
      "id": "01HXYZ...",
      "title": "Email Template",
      "slug": "email-template",
      "description": "A reusable email template",
      "labels": ["email", "marketing"],
      "author": "user",
      "created_at": "2024-01-01T00:00:00Z",
      "updated_at": "2024-01-02T00:00:00Z",
      "type": "template",
      "variables": [
        {
          "name": "recipient_name",
          "description": "Name of the recipient",
          "default": "User"
        }
      ]
    }
  ],
  "count": 1,
  "total": 1
}
```

#### 2.2 Create New Template
```http
POST /templates
```

**Request Body:**
```json
{
  "content": "---\ntitle: My Template\ndescription: A new template\nlabels: [\"test\"]\nauthor: john\nvariables:\n  - name: user_name\n    description: User's name\n    default: Guest\n---\n\n# Hello {{user_name}}\n\nWelcome!"
}
```

**Response:**
```json
{
  "id": "01HXYZ...",
  "version_id": "2024-01-01T12-00Z_abc12",
  "created_at": "2024-01-01T12:00:00Z"
}
```

#### 2.3 Get Template Detail
```http
GET /templates/{id}
```

**Response:**
```json
{
  "id": "01HXYZ...",
  "metadata": {
    "id": "01HXYZ...",
    "title": "My Template",
    "description": "A new template",
    "labels": ["test"],
    "author": "john",
    "created_at": "2024-01-01T12:00:00Z",
    "updated_at": "2024-01-01T12:00:00Z",
    "type": "template",
    "variables": [
      {
        "name": "user_name",
        "description": "User's name",
        "default": "Guest"
      }
    ]
  },
  "content": "# Hello {{user_name}}\n\nWelcome!",
  "full_content": "---\ntitle: My Template\n...\n---\n\n# Hello {{user_name}}\n..."
}
```

#### 2.4 Update Template
```http
PUT /templates/{id}
```

Similar to Prompt update.

#### 2.5 Delete Template
```http
DELETE /templates/{id}
```

**Response:** 204 No Content

#### 2.6 List Template Versions
```http
GET /templates/{id}/versions
```

Similar to Prompt versions.

#### 2.7 Get Specific Template Version
```http
GET /templates/{id}/versions/{version_id}
```

Similar to Prompt version detail.

---

### 3. Chats (Chat Histories)

#### 3.1 List All Chats
```http
GET /chats
```

**Query Parameters:**
- `provider` (string, optional): 按AI提供商筛选
- `limit` (number, optional): 限制返回数量，默认100

**Response:**
```json
{
  "chats": [
    {
      "id": "01HXYZ...",
      "title": "Discussion about AI",
      "description": "A conversation about artificial intelligence",
      "provider": "ChatGPT",
      "conversation_id": "original-conv-id",
      "turn_count": 5,
      "tags": ["ai", "discussion"],
      "created_at": "2024-01-01T00:00:00Z",
      "updated_at": "2024-01-01T01:00:00Z",
      "messages": [
        {
          "role": "user",
          "content": "What is AI?"
        },
        {
          "role": "assistant",
          "content": "AI stands for Artificial Intelligence..."
        }
      ]
    }
  ],
  "count": 1,
  "total": 1
}
```

#### 3.2 Create New Chat
```http
POST /chats
```

**Request Body:**
```json
{
  "title": "My Chat",
  "description": "A saved chat",
  "provider": "Claude",
  "conversation_id": "conv-123",
  "tags": ["test"],
  "messages": [
    {
      "role": "user",
      "content": "Hello"
    },
    {
      "role": "assistant",
      "content": "Hi there!"
    }
  ]
}
```

**Note:** If a chat with the same `provider` and `conversation_id` exists, it will be updated instead of creating a new one (deduplication).

**Response:**
```json
{
  "id": "01HXYZ...",
  "created_at": "2024-01-01T12:00:00Z",
  "message": "Chat created"
}
```

#### 3.3 Get Chat Detail
```http
GET /chats/{id}
```

**Response:**
```json
{
  "id": "01HXYZ...",
  "title": "My Chat",
  "description": "A saved chat",
  "provider": "Claude",
  "conversation_id": "conv-123",
  "turn_count": 1,
  "tags": ["test"],
  "created_at": "2024-01-01T12:00:00Z",
  "updated_at": "2024-01-01T12:00:00Z",
  "messages": [
    {
      "role": "user",
      "content": "Hello"
    },
    {
      "role": "assistant",
      "content": "Hi there!"
    }
  ]
}
```

#### 3.4 Update Chat
```http
PUT /chats/{id}
```

**Request Body:**
```json
{
  "title": "Updated Chat Title",
  "messages": [ ... ]
}
```

**Response:**
```json
{
  "id": "01HXYZ...",
  "updated_at": "2024-01-01T13:00:00Z"
}
```

#### 3.5 Delete Chat
```http
DELETE /chats/{id}
```

**Response:** 204 No Content

---

### 4. Common APIs

#### 4.1 Search
```http
GET /search
```

**Query Parameters:**
- `type` (string, optional): 类型筛选 ("prompt", "template", "chat")
- `labels` (array, optional): 标签筛选（AND逻辑）
- `slug` (string, optional): 按slug筛选
- `author` (string, optional): 按作者筛选
- `limit` (number, optional): 限制返回数量，默认50
- `cursor` (string, optional): 分页游标

**Response:**
```json
{
  "items": [ ... ],
  "count": 10,
  "next_cursor": "01HXYZ..."
}
```

#### 4.2 Index Status
```http
GET /index/status
```

**Response:**
```json
{
  "prompts_count": 10,
  "templates_count": 5,
  "chats_count": 20,
  "last_updated": "2024-01-01T12:00:00Z",
  "index_size_bytes": 4096
}
```

#### 4.3 Rebuild Index
```http
POST /index/rebuild
```

**Response:**
```json
{
  "status": "completed",
  "stats": {
    "prompts_added": 10,
    "templates_added": 5,
    "chats_added": 20,
    "errors": []
  }
}
```

#### 4.4 Health Check
```http
GET /health
```

**Response:**
```json
{
  "status": "healthy",
  "storage": {
    "healthy": true
  },
  "index": {
    "healthy": true,
    "prompts_count": 10,
    "templates_count": 5,
    "chats_count": 20,
    "last_updated": "2024-01-01T12:00:00Z",
    "index_size_bytes": 4096
  }
}
```

---

## Error Responses

All endpoints may return the following error responses:

### 400 Bad Request
```json
{
  "error": "BadRequest",
  "message": "content is required"
}
```

### 404 Not Found
```json
{
  "error": "ResourceNotFound",
  "message": "Prompt 01HXYZ... not found"
}
```

### 409 Conflict
```json
{
  "error": "Conflict",
  "message": "Resource already exists"
}
```

### 422 Validation Error
```json
{
  "error": "ValidationError",
  "message": "title is required in frontmatter"
}
```

### 500 Internal Server Error
```json
{
  "error": "InternalServerError",
  "message": "An unexpected error occurred"
}
```

---

## Frontend Integration Notes

### 1. **Prompt/Template Creation Flow**

When creating a new Prompt or Template from the frontend:

```javascript
// Frontend: PromptCreate
const createPrompt = async (metadata, content) => {
  const frontmatter = `---
title: ${metadata.title}
description: ${metadata.description}
labels: ${JSON.stringify(metadata.labels)}
author: ${metadata.author}
---

${content}`;

  const response = await fetch('/api/v1/prompts', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ content: frontmatter })
  });

  return response.json();
};
```

### 2. **Template Variables**

For Templates, include the `variables` array in the frontmatter:

```yaml
---
title: Email Template
description: A reusable email template
labels: ["email"]
author: john
variables:
  - name: recipient_name
    description: Name of the recipient
    default: User
  - name: subject
    description: Email subject line
    default: Welcome
---

# Hello {{recipient_name}}

Subject: {{subject}}
```

### 3. **Chat History Sync**

The browser extension should use the following format when syncing chat histories:

```javascript
// Browser Extension
const syncChatHistory = async (chatData) => {
  const response = await fetch('/api/v1/chats', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      title: chatData.title,
      description: chatData.description,
      provider: 'ChatGPT', // or 'Claude', 'Gemini', etc.
      conversation_id: chatData.originalId, // For deduplication
      tags: chatData.tags,
      messages: chatData.messages // OpenAI format
    })
  });

  return response.json();
};
```

### 4. **Pagination**

For large datasets, use cursor-based pagination:

```javascript
const loadMoreItems = async (cursor) => {
  const response = await fetch(`/api/v1/search?type=prompt&limit=20&cursor=${cursor}`);
  const data = await response.json();

  // data.items - current page items
  // data.next_cursor - cursor for next page (null if last page)
};
```

---

## Version Control

### Understanding Versions

- Each Prompt/Template maintains a history of versions
- Versions are immutable - once created, they cannot be modified
- The `HEAD` file points to the latest version
- Version IDs follow the format: `YYYY-MM-DDTHH-MMZ_{random}`

### Version Workflow

1. **Create**: Creates initial version (v1)
2. **Update**: Creates new version (v2, v3, etc.)
3. **List Versions**: View all historical versions
4. **Get Specific Version**: Retrieve content of any version
5. **HEAD**: Always points to the latest version

---

## Best Practices

### 1. **Slug Naming**
- Use lowercase
- Separate words with hyphens
- Keep it short (max 50 characters)
- Make it descriptive

### 2. **Labels/Tags**
- Use consistent naming conventions
- Create a taxonomy for common labels
- Support multi-label filtering in UI

### 3. **Version Management**
- Create new versions for significant changes
- Use descriptive commit messages (if implementing version notes)
- Consider semantic versioning for major changes

### 4. **Chat Deduplication**
- Always include `provider` and `conversation_id` when syncing chats
- The system will automatically update existing chats instead of creating duplicates

---

## Migration Notes

### From Git-based to File-based System

The current system uses a file-based storage with version control:

- ✅ No Git dependency
- ✅ Faster operations
- ✅ Simpler deployment
- ✅ JSON index for fast searches
- ✅ File locking for concurrency

### Data Structure

```
storage/
├── prompts/
│   └── prompt_{slug}-{id}/
│       ├── prompt.yaml           # 完整元数据（单一数据源）
│       ├── HEAD                   # 指向最新版本
│       └── versions/
│           ├── pv_{slug}-{id}_{version_id}.md  # 最小Front Matter + 内容
│           └── ...
├── templates/
│   └── template_{slug}-{id}/
│       ├── template.yaml         # 完整元数据（包括variables）
│       ├── HEAD
│       └── versions/
│           ├── tv_{slug}-{id}_{version_id}.md  # 最小Front Matter + variables + 内容
│           └── ...
├── chats/
│   └── chat_{slug}-{id}.json    # 完整JSON（OpenAI格式）
└── index.json                    # 快速查询索引
```

### 数据分离策略

**Prompt/Template存储优化：**

1. **YAML文件** (`prompt.yaml` / `template.yaml`)
   - 存储完整元数据（title、description、labels、author、timestamps等）
   - 作为元数据的**单一数据源**
   - 更新元数据只需修改此文件

2. **Markdown文件** (`pv_*.md` / `tv_*.md`)
   - Front Matter **仅存储最小必要信息**：
     - `id`, `created_at`, `created_by`
     - `variables`（仅Template，版本特定）
   - 避免数据冗余
   - 版本文件保持不可变（immutable）

3. **读取时自动合并**
   - `read_version()` 自动合并YAML元数据和Markdown Front Matter
   - API层透明，无需关心内部存储细节

**好处：**
- ✅ 减少数据冗余
- ✅ 元数据集中管理
- ✅ 支持版本特定数据（Template的variables）
- ✅ 提高查询性能（列表查询只读YAML）
```
