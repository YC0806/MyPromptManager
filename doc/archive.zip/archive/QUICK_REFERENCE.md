# 快速参考 - 后端存储逻辑

## 📦 数据存储位置

### Prompt
```
prompts/
  └── prompt_{slug}-{id}/
      ├── prompt.yaml          ← 完整元数据
      ├── HEAD                 ← 指向最新版本
      └── versions/
          └── pv_*.md         ← 最小Front Matter + 内容
```

### Template
```
templates/
  └── template_{slug}-{id}/
      ├── template.yaml       ← 完整元数据 + variables
      ├── HEAD
      └── versions/
          └── tv_*.md        ← 最小Front Matter + variables + 内容
```

### ChatHistory
```
chats/
  └── chat_{slug}-{id}.json  ← 完整JSON（OpenAI格式）
```

---

## 📝 Front Matter内容

### Prompt的Markdown Front Matter
```json
{
  "id": "01K9S...",
  "created_at": "2025-11-11T10:00:00Z",
  "created_by": "john_doe"
}
```

### Template的Markdown Front Matter
```json
{
  "id": "01K9S...",
  "created_at": "2025-11-11T10:00:00Z",
  "created_by": "jane_doe",
  "variables": [
    {
      "name": "recipient_name",
      "description": "Name of the recipient",
      "default": "User"
    }
  ]
}
```

---

## 🔑 核心原则

| 数据类型 | 存储位置 | 说明 |
|---------|---------|------|
| **元数据** | YAML文件 | 完整的title、description、labels等 |
| **版本基本信息** | Markdown Front Matter | 只有id、created_at、created_by |
| **版本特定数据** | Markdown Front Matter | Template的variables（可变） |
| **版本内容** | Markdown Body | 实际的提示词/模版内容 |

---

## 🔄 关键方法

### create_item()
- 接收：完整metadata + content
- 写入YAML：完整metadata
- 写入Markdown：最小Front Matter + content

### create_version()
- 接收：更新的metadata + content
- 读取YAML：获取created_at/created_by
- 写入Markdown：最小Front Matter + content
- 更新YAML：新的metadata

### read_version()
- 读取YAML：完整metadata
- 读取Markdown：最小Front Matter + content
- 合并返回：完整metadata + content

---

## ✅ 测试命令

```bash
# 运行存储逻辑测试
python test_storage_logic.py

# 预期输出
✅ Prompt storage test PASSED!
✅ Template storage test PASSED!
✅ ALL TESTS PASSED!
```

---

## 📚 详细文档

| 文档 | 用途 |
|------|------|
| [STORAGE_REFACTOR_SUMMARY.md](STORAGE_REFACTOR_SUMMARY.md) | 详细的重构说明 |
| [FINAL_CHANGES_SUMMARY.md](FINAL_CHANGES_SUMMARY.md) | 修改总结 |
| [API_DOCUMENTATION.md](API_DOCUMENTATION.md) | API规范 |

---

## 🎯 关键优势

1. ✅ **减少冗余** - 元数据只存储一次（YAML）
2. ✅ **集中管理** - 更新元数据只需修改YAML
3. ✅ **版本特定** - Template的variables可在不同版本中变化
4. ✅ **性能优化** - 列表查询只读小型YAML文件
5. ✅ **API透明** - 前后端代码无需修改

---

## 💡 常见问题

### Q: 前端需要修改吗？
**A:** 不需要。前端继续发送完整Markdown，后端自动分离存储。

### Q: API需要修改吗？
**A:** 不需要。Storage层自动处理数据合并和分离。

### Q: 如何更新元数据？
**A:** 只需修改YAML文件，版本文件保持不变。

### Q: Variables存储在哪里？
**A:** Template的variables存储在两个地方：
- YAML：当前（HEAD）版本的variables
- Markdown Front Matter：该版本特定的variables

### Q: 为什么Front Matter要最小化？
**A:**
- 避免数据冗余
- 减少版本文件大小
- 元数据统一管理
- 版本文件保持不可变

---

**最后更新：** 2025-11-11
