# 测试数据生成说明

本文档说明如何生成和使用测试数据。

## 📋 测试数据内容

### 1. 提示词 (Prompts) - 5 个

| ID | 标题 | 描述 | 标签 |
|----|------|------|------|
| `17624181723706T8HN33F0NQD6QF0` | 代码审查助手 | 帮助开发者进行代码审查，提供改进建议 | 开发, 代码审查, 最佳实践 |
| `17624181724103TE6T2WEETFAQ5PH` | API 文档生成器 | 根据代码自动生成 API 文档 | 文档, API, 自动化 |
| `176241817244206J50MDRNJSVMQW1` | SQL 查询优化器 | 分析和优化 SQL 查询性能 | 数据库, SQL, 性能优化 |
| `1762418172474KXZHE0MVNG3ZKZFC` | 技术文章写作助手 | 帮助撰写技术博客文章 | 写作, 技术博客, 教程 |
| `17624181724983EXFK8YP9FDVF4XJ` | Bug 调试助手 | 帮助定位和修复代码 bug | 调试, 故障排查, 开发 |

**发布状态**：
- ✅ 前 3 个提示词已发布 v1.0.0 (prod channel)
- ⏳ 后 2 个提示词为草稿状态

### 2. 模版 (Templates) - 3 个

| ID | 标题 | 描述 | 变量 |
|----|------|------|------|
| `1762418172522V46Z9ACQ91BNYDME` | 代码生成模版 | 通用代码生成模版，支持多种编程语言 | LANGUAGE, FEATURE, FRAMEWORK |
| `1762418172546399G97XQ0CWVBHEV` | 测试用例模版 | 测试用例生成模版 | FEATURE, TEST_TYPE, FRAMEWORK |
| `17624181725703J7B8F3DQQHGBE0A` | 数据分析模版 | 数据分析任务模版 | DATASET, ANALYSIS_GOAL, METRICS |

**状态**：全部为草稿状态

### 3. 对话历史 (Chats) - 2 个

| ID | 标题 | 描述 | 标签 |
|----|------|------|------|
| `1762418172594N6KANY37VKC3JG48` | 讨论代码重构方案 | 与 AI 讨论如何重构一个复杂的 Python 模块 | 重构, Python, 架构设计 |
| `17624181726174ABX9PTNHRH311HG` | API 设计讨论 | 讨论 RESTful API 的设计最佳实践 | API, REST, 设计 |

---

## 🚀 快速使用

### 生成测试数据

```bash
# 从项目根目录运行
python generate_test_data.py
```

### 查看生成的数据

```bash
# 进入仓库目录
cd repo_root

# 查看所有文件
find projects -type f

# 查看提示词
ls -l projects/default/prompts/

# 查看模版
ls -l projects/default/templates/

# 查看对话历史
ls -l projects/default/chats/

# 查看索引
cat .promptmeta/index.json | python -m json.tool
```

### 查看 Git 历史

```bash
cd repo_root

# 查看提交历史
git log --oneline

# 查看详细提交
git log --stat

# 查看发布标签
git tag

# 查看标签详情
git show prompt/17624181723706T8HN33F0NQD6QF0/v1.0.0
```

---

## 📁 目录结构

```
repo_root/
├── .git/                              # Git 仓库
├── .promptmeta/                       # 元数据
│   ├── index.json                    # 索引文件（5 个提示词 + 3 个模版）
│   ├── index.lock                    # 索引锁
│   └── schema/                       # Schema 目录
└── projects/
    └── default/
        ├── prompts/                  # 提示词目录
        │   ├── prompt_17624181723706T8HN33F0NQD6QF0.md  (已发布 v1.0.0)
        │   ├── prompt_17624181724103TE6T2WEETFAQ5PH.md  (已发布 v1.0.0)
        │   ├── prompt_176241817244206J50MDRNJSVMQW1.md  (已发布 v1.0.0)
        │   ├── prompt_1762418172474KXZHE0MVNG3ZKZFC.md  (草稿)
        │   └── prompt_17624181724983EXFK8YP9FDVF4XJ.md  (草稿)
        ├── templates/                # 模版目录
        │   ├── template_1762418172522V46Z9ACQ91BNYDME.md
        │   ├── template_1762418172546399G97XQ0CWVBHEV.md
        │   └── template_17624181725703J7B8F3DQQHGBE0A.md
        └── chats/                    # 对话历史目录
            ├── chat_1762418172594N6KANY37VKC3JG48.json
            └── chat_17624181726174ABX9PTNHRH311HG.json
```

---

## 📖 文件格式说明

### 提示词/模版文件格式 (Markdown + YAML Front Matter)

```markdown
---
{
  "id": "17624181723706T8HN33F0NQD6QF0",
  "title": "代码审查助手",
  "slug": "code-review-assistant",
  "description": "帮助开发者进行代码审查，提供改进建议",
  "type": "prompt",
  "labels": ["开发", "代码审查", "最佳实践"],
  "created_at": "2025-11-06T16:36:12.370453",
  "updated_at": "2025-11-06T16:36:12.370465",
  "version": "1.0.0",
  "status": "draft"
}
---

# 代码审查助手

你是一个专业的代码审查专家...
```

### 对话历史文件格式 (JSON)

```json
{
  "id": "1762418172594N6KANY37VKC3JG48",
  "title": "讨论代码重构方案",
  "description": "与 AI 讨论如何重构一个复杂的 Python 模块",
  "tags": ["重构", "Python", "架构设计"],
  "created_at": "2025-11-06T16:36:12.594126",
  "updated_at": "2025-11-06T16:36:12.594136",
  "messages": [
    {
      "role": "user",
      "content": "我有一个 500 行的 Python 模块...",
      "timestamp": "2024-11-01T10:00:00Z"
    },
    {
      "role": "assistant",
      "content": "理解你的困境...",
      "timestamp": "2024-11-01T10:01:00Z"
    }
  ]
}
```

---

## 🔧 脚本功能

### `generate_test_data.py` 功能

1. **初始化 Git 仓库**
   - 配置 Git 用户信息（Test User <test@example.com>）

2. **创建提示词**
   - 生成 5 个提示词文件（Markdown + Front Matter）
   - 每个提示词独立 Git 提交
   - 前 3 个提示词自动发布 v1.0.0 版本（prod channel）

3. **创建模版**
   - 生成 3 个模版文件
   - 包含变量定义
   - 每个模版独立 Git 提交

4. **创建对话历史**
   - 生成 2 个对话记录（JSON 格式）
   - 包含完整的多轮对话
   - 每个对话独立 Git 提交

5. **更新索引**
   - 扫描所有提示词和模版
   - 生成 `index.json` 索引文件
   - 包含完整的元数据

### Git 标签格式

发布的版本使用注释标签（annotated tag）：

```
标签名称：prompt/{PROMPT_ID}/v1.0.0
标签消息（JSON）：
{
  "channel": "prod",
  "notes": "Initial release of 代码审查助手",
  "released_at": "2025-11-06T16:36:12.370453",
  "version": "v1.0.0"
}
```

---

## 🎯 使用场景

### 1. 测试前端界面

```bash
# 启动后端
python manage.py runserver

# 启动前端（新终端）
./start-frontend.sh

# 访问 http://localhost:3000
# 现在可以看到：
# - Dashboard 显示 5 个提示词统计
# - Prompts 列表显示所有提示词
# - 3 个已发布版本
# - Timeline 显示历史记录
```

### 2. 测试 API 端点

```bash
# 查询所有提示词
curl http://127.0.0.1:8000/v1/search?project=default

# 获取特定提示词内容
curl http://127.0.0.1:8000/v1/simple/prompts/17624181723706T8HN33F0NQD6QF0/content?ref=latest

# 获取时间线
curl http://127.0.0.1:8000/v1/simple/prompts/17624181723706T8HN33F0NQD6QF0/timeline?view=all

# 获取发布列表
curl http://127.0.0.1:8000/v1/detail/prompts/17624181723706T8HN33F0NQD6QF0/releases
```

### 3. 测试版本管理

```bash
cd repo_root

# 查看发布的版本
git tag -l "prompt/*/v*"

# 查看版本详情
git show prompt/17624181723706T8HN33F0NQD6QF0/v1.0.0

# 查看提交历史
git log --oneline --all --graph
```

### 4. 测试索引功能

```bash
# 查看索引内容
cat repo_root/.promptmeta/index.json | python -m json.tool

# 测试索引修复（通过 API）
curl -X POST http://127.0.0.1:8000/v1/index/repair

# 测试索引重建（通过 API）
curl -X POST http://127.0.0.1:8000/v1/index/rebuild
```

---

## 🔄 重新生成测试数据

如果需要重新生成干净的测试数据：

```bash
# 1. 删除现有仓库
rm -rf repo_root

# 2. 重新创建目录结构
mkdir -p repo_root/.promptmeta/schema
mkdir -p repo_root/projects/default/{prompts,templates,chats}

# 3. 初始化 Git
cd repo_root && git init && cd ..

# 4. 运行生成脚本
python generate_test_data.py
```

---

## 📊 测试数据统计

- **总文件数**：10 个
  - 5 个提示词文件 (`.md`)
  - 3 个模版文件 (`.md`)
  - 2 个对话历史文件 (`.json`)

- **Git 提交数**：10 个
  - 每个文件一个独立提交

- **Git 标签数**：3 个
  - 3 个提示词的 v1.0.0 发布标签

- **索引条目**：8 个
  - 5 个提示词索引
  - 3 个模版索引

---

## ✅ 验证清单

生成测试数据后，请验证以下内容：

- [ ] `repo_root/.git` 目录存在
- [ ] `repo_root/.promptmeta/index.json` 包含 5 个提示词和 3 个模版
- [ ] `repo_root/projects/default/prompts/` 包含 5 个 `.md` 文件
- [ ] `repo_root/projects/default/templates/` 包含 3 个 `.md` 文件
- [ ] `repo_root/projects/default/chats/` 包含 2 个 `.json` 文件
- [ ] `git log` 显示 10 个提交
- [ ] `git tag` 显示 3 个标签
- [ ] 前端可以正常显示所有数据
- [ ] API 端点可以正常访问

---

## 🐛 故障排除

### 问题 1：脚本运行失败

```bash
# 检查 Python 环境
python --version

# 确保在项目根目录
pwd
# 应该显示：/Users/guoyuchen/Documents/Project/MyPromptManager
```

### 问题 2：Git 配置错误

```bash
cd repo_root
git config user.name
git config user.email

# 如果没有配置，手动设置
git config user.name "Test User"
git config user.email "test@example.com"
```

### 问题 3：前端无法显示数据

```bash
# 检查后端是否运行
curl http://127.0.0.1:8000/v1/health

# 检查索引文件
cat repo_root/.promptmeta/index.json

# 重建索引
curl -X POST http://127.0.0.1:8000/v1/index/rebuild
```

---

## 📚 相关文档

- [README.md](README.md) - 项目总览
- [CLAUDE.md](CLAUDE.md) - API 规范
- [LOCAL_SETUP.md](LOCAL_SETUP.md) - 本地使用配置
- [USAGE_EXAMPLES.md](USAGE_EXAMPLES.md) - 使用示例

---

**生成时间**：2025-11-06
**版本**：1.0.0
**状态**：✅ 可用
