# AI Histories 合并到 Chats - 迁移说明

## 概述

为了简化架构并避免冗余，我们已将 `ai-histories` API 合并到 `chats` API 中。现在所有来自浏览器插件的 AI 对话历史都统一存储为 Chats。

## 主要变更

### 1. API 端点变更

**已删除的端点**:
- ❌ `POST /v1/ai-histories`
- ❌ `GET /v1/ai-histories`
- ❌ `GET /v1/ai-histories/{history_id}`
- ❌ `PUT /v1/ai-histories/{history_id}`
- ❌ `DELETE /v1/ai-histories/{history_id}`

**使用以下端点替代**:
- ✅ `POST /v1/chats` - 创建/更新对话（支持自动去重）
- ✅ `GET /v1/chats` - 获取对话列表（支持 provider 过滤）
- ✅ `GET /v1/chats/{chat_id}` - 获取单个对话
- ✅ `PUT /v1/chats/{chat_id}` - 更新对话
- ✅ `DELETE /v1/chats/{chat_id}` - 删除对话

### 2. 后端代码变更

#### [apps/api/urls.py](apps/api/urls.py:20-22)
```python
# 已删除
# path('ai-histories', views.AIHistoriesListView.as_view(), name='ai-histories-list'),
# path('ai-histories/<str:history_id>', views.AIHistoryDetailView.as_view(), name='ai-history-detail'),

# 现在使用
path('chats', views.ChatsListView.as_view(), name='chats-list'),
path('chats/<str:chat_id>', views.ChatDetailView.as_view(), name='chat-detail'),
```

#### [apps/api/views.py](apps/api/views.py:458-565)
- ✅ 增强了 `ChatsListView.post()` 支持 `provider` + `conversation_id` 自动去重
- ✅ `ChatsListView.get()` 支持 `provider` 参数过滤
- ❌ 删除了 `AIHistoriesListView` 和 `AIHistoryDetailView`

#### [apps/core/services/file_storage_service.py](apps/core/services/file_storage_service.py:408-426)
- ✅ 添加了 `find_chat_by_conversation(provider, conversation_id)` 方法
- ℹ️ 保留了 AI History 相关方法（用于数据迁移，可选择性删除）

### 3. 浏览器插件变更

#### [browser-extension/background.js](browser-extension/background.js:79)
```javascript
// 旧版本
fetch(`${apiUrl}/ai-histories`, { ... })

// 新版本
fetch(`${apiUrl}/chats`, { ... })
```

#### [browser-extension/test_api.sh](browser-extension/test_api.sh)
- 更新所有测试用例使用 `/v1/chats` 端点
- 测试自动去重功能
- 测试 provider 过滤

## Chats API 的新功能

### 自动去重

当使用 `POST /v1/chats` 创建对话时，如果请求包含 `provider` 和 `conversation_id` 字段：

```json
{
  "provider": "ChatGPT",
  "conversation_id": "abc123",
  "title": "My Conversation",
  "messages": [...]
}
```

后端会：
1. 检查是否存在相同 `provider` + `conversation_id` 的对话
2. 如果存在，**更新**现有对话并返回 `"message": "Chat updated"`
3. 如果不存在，**创建**新对话并返回 `"message": "Chat created"`

### Provider 过滤

```bash
# 获取所有 ChatGPT 对话
GET /v1/chats?provider=ChatGPT

# 获取所有 Claude 对话
GET /v1/chats?provider=Claude
```

## 数据格式兼容性

Chats API 完全兼容之前 AI Histories 的数据格式：

```json
{
  "provider": "ChatGPT",
  "conversation_id": "unique-id",
  "title": "对话标题",
  "messages": [
    {
      "role": "user",
      "content": "消息内容",
      "timestamp": null,
      "index": 0
    }
  ],
  "metadata": {
    "url": "https://...",
    "extracted_at": "2024-01-01T00:00:00Z",
    "messageCount": 1
  },
  "created_at": "2024-01-01T00:00:00Z",
  "updated_at": "2024-01-01T00:00:00Z"
}
```

## 数据迁移

### 存储位置

- **AI Histories**: `data/ai-histories/history_*.json`
- **Chats**: `data/chats/chat_*.json`

### 迁移步骤（可选）

如果你有现有的 AI Histories 数据需要迁移到 Chats：

```bash
# 1. 备份现有数据
cp -r data/ai-histories data/ai-histories.backup

# 2. 迁移数据（手动或使用脚本）
# 将 ai-histories 目录下的文件复制到 chats 目录
# 重命名文件格式：history_*.json -> chat_*.json

# 3. 重建索引
curl -X POST http://localhost:8000/v1/index/rebuild
```

**注意**: 迁移脚本尚未提供。如果数据量不大，建议重新从浏览器插件同步。

### 清理旧数据（可选）

迁移完成后，可以删除旧的 ai-histories 数据：

```bash
# 确认数据已迁移后
rm -rf data/ai-histories
```

## 测试

运行测试验证迁移成功：

```bash
cd browser-extension
./test_api.sh
```

所有测试应该通过，包括：
- ✅ 创建新对话
- ✅ 自动去重（相同 provider + conversation_id）
- ✅ Provider 过滤
- ✅ 更新对话
- ✅ 删除对话

## 影响范围

### 需要更新的组件

- ✅ 后端 API (apps/api/urls.py, apps/api/views.py)
- ✅ 文件存储服务 (apps/core/services/file_storage_service.py)
- ✅ 浏览器插件 (browser-extension/background.js)
- ✅ API 测试脚本 (browser-extension/test_api.sh)
- ✅ 文档 (browser-extension/API_INTEGRATION.md)

### 不受影响的组件

- ✅ 前端 UI（如果前端没有直接使用 ai-histories API）
- ✅ Content Scripts（只需要 background.js 中的 API 调用变更）
- ✅ 本地存储逻辑（浏览器插件的本地存储键名可以保持不变）

## 优势

1. **简化架构**: 减少重复的 API 端点和数据模型
2. **统一管理**: 所有对话（手动创建或浏览器插件提取）统一在 Chats 中
3. **代码复用**: 减少重复代码，降低维护成本
4. **功能一致**: Chats 和 AI Histories 本质上都是对话记录，合并后功能更一致
5. **自动去重**: 浏览器插件提取的对话自动去重，避免重复存储

## 回滚计划

如果需要回滚到旧版本：

1. 恢复 `apps/api/urls.py` 和 `apps/api/views.py` 中的 AI Histories 视图
2. 恢复 `browser-extension/background.js` 中的 API 调用
3. 重新部署后端和浏览器插件

**注意**: file_storage_service.py 中的 AI History 方法暂时保留，以便快速回滚。

## 常见问题

### Q: 旧的 AI Histories 数据会丢失吗？
A: 不会。旧数据保留在 `data/ai-histories/` 目录中。你可以选择手动迁移或保留作为备份。

### Q: 前端需要修改吗？
A: 如果前端直接使用 `/v1/ai-histories` 端点，需要改为 `/v1/chats`。如果前端没有直接调用这些 API，不需要修改。

### Q: 浏览器插件用户需要做什么？
A: 用户只需要重新加载插件即可。插件会自动使用新的 API 端点。

### Q: 如何区分普通 Chats 和从浏览器提取的 Chats？
A: 从浏览器提取的 Chats 包含 `provider` 和 `conversation_id` 字段。可以通过这些字段过滤：
```bash
GET /v1/chats?provider=ChatGPT
```

## 相关文件

- [apps/api/urls.py](apps/api/urls.py)
- [apps/api/views.py](apps/api/views.py)
- [apps/core/services/file_storage_service.py](apps/core/services/file_storage_service.py)
- [browser-extension/background.js](browser-extension/background.js)
- [browser-extension/test_api.sh](browser-extension/test_api.sh)
- [browser-extension/API_INTEGRATION.md](browser-extension/API_INTEGRATION.md)

## 完成日期

2025-11-10

## 版本

v1.1
