# 多项目测试数据说明文档

本文档说明如何使用多项目测试数据，包括数据结构、生成方法和测试验证。

---

## 📊 测试数据概览

### 项目统计

| 项目 | 提示词数量 | 模版数量 | 发布版本 | 作者 |
|------|-----------|---------|---------|------|
| **default** | 8 个 | 4 个 | 2 个 v1.0.0 | admin, anonymous |
| **frontend** | 2 个 | 1 个 | 1 个 v1.0.0 | developer |
| **backend** | 2 个 | 1 个 | 2 个 (v2.0.0, v1.1.0) | backend-dev |
| **总计** | **12 个** | **6 个** | **5 个** | - |

---

## 📁 项目详细内容

### 1️⃣ Default 项目

**描述**: 默认项目，包含通用的开发工具和提示词

#### 提示词 (8 个)

| 标题 | 描述 | 标签 | 发布状态 |
|------|------|------|---------|
| 代码审查助手 | 帮助开发者进行代码审查，提供改进建议 | 开发, 代码审查, 最佳实践 | ✅ v1.0.0 (prod) |
| API 文档生成器 | 根据代码自动生成 API 文档 | 文档, API, 自动化 | ✅ v1.0.0 (prod) |
| SQL 查询优化器 | 分析和优化 SQL 查询性能 | 数据库, SQL, 性能优化 | ⏳ 草稿 |
| 技术文章写作助手 | 帮助撰写技术博客文章 | 写作, 技术博客, 教程 | ⏳ 草稿 |
| Bug 调试助手 | 帮助定位和修复代码 bug | 调试, 故障排查, 开发 | ⏳ 草稿 |

*注：还包含 3 个来自旧数据的提示词*

#### 模版 (4 个)

| 标题 | 描述 | 变量 |
|------|------|------|
| 代码生成模版 | 通用代码生成模版，支持多种编程语言 | LANGUAGE, FEATURE, FRAMEWORK |
| 测试用例模版 | 测试用例生成模版 | FEATURE, TEST_TYPE, FRAMEWORK |
| 数据分析模版 | 数据分析任务模版 | DATASET, ANALYSIS_GOAL, METRICS |

*注：还包含 1 个来自旧数据的模版*

---

### 2️⃣ Frontend 项目

**描述**: 前端开发项目，专注于 React、Vue 等前端技术

#### 提示词 (2 个)

| 标题 | 描述 | 标签 | 发布状态 |
|------|------|------|---------|
| React 组件生成器 | 生成 React 功能组件和 Hooks | React, 前端, 组件 | ✅ v1.0.0 (prod) |
| CSS 样式优化器 | 优化和重构 CSS 代码 | CSS, 优化, 前端 | ⏳ 草稿 |

#### 模版 (1 个)

| 标题 | 描述 | 变量 |
|------|------|------|
| Vue 组件模版 | Vue 3 Composition API 组件模版 | COMPONENT_NAME, PROPS, EMITS |

---

### 3️⃣ Backend 项目

**描述**: 后端开发项目，包含 API 设计、数据库等内容

#### 提示词 (2 个)

| 标题 | 描述 | 标签 | 发布状态 |
|------|------|------|---------|
| RESTful API 设计器 | 设计符合 REST 规范的 API | API, REST, 后端 | ✅ v2.0.0 (prod) |
| 数据库 Schema 设计器 | 设计数据库表结构和关系 | 数据库, 设计, Schema | ✅ v1.1.0 (prod) |

#### 模版 (1 个)

| 标题 | 描述 | 变量 |
|------|------|------|
| GraphQL Schema 模版 | GraphQL API Schema 定义模版 | TYPE_NAME, FIELDS, RESOLVERS |

---

## 📂 目录结构

```
repo_root/
├── .git/                                    # Git 仓库
├── .promptmeta/                             # 元数据目录
│   ├── index.json                          # 索引文件（12 个提示词 + 6 个模版）
│   ├── index.lock                          # 索引锁文件
│   └── schema/                             # Schema 定义
└── projects/                               # 项目根目录
    ├── default/                            # 默认项目
    │   ├── prompts/                       # 8 个提示词文件
    │   │   ├── prompt_17624365042563BAHD83S771V4G3F.md  (v1.0.0)
    │   │   ├── prompt_1762436504305RQA7K61S5QQRXZN9.md  (v1.0.0)
    │   │   ├── prompt_1762436504348YT66YWQVGP3BJNQX.md  (草稿)
    │   │   ├── prompt_17624181723706T8HN33F0NQD6QF0.md  (v1.0.0)
    │   │   ├── prompt_17624181724103TE6T2WEETFAQ5PH.md  (v1.0.0)
    │   │   ├── prompt_176241817244206J50MDRNJSVMQW1.md  (v1.0.0)
    │   │   ├── prompt_1762418172474KXZHE0MVNG3ZKZFC.md  (草稿)
    │   │   └── prompt_17624181724983EXFK8YP9FDVF4XJ.md  (草稿)
    │   ├── templates/                     # 4 个模版文件
    │   │   ├── template_1762436504386B5RN9WNAB1PZ036S.md
    │   │   ├── template_1762418172522V46Z9ACQ91BNYDME.md
    │   │   ├── template_1762418172546399G97XQ0CWVBHEV.md
    │   │   └── template_17624181725703J7B8F3DQQHGBE0A.md
    │   └── chats/                         # 2 个对话历史
    │       ├── chat_1762418172594N6KANY37VKC3JG48.json
    │       └── chat_17624181726174ABX9PTNHRH311HG.json
    ├── frontend/                           # 前端项目
    │   ├── prompts/                       # 2 个提示词文件
    │   │   ├── prompt_17624365044222YX6MTA14HHQSZGQ.md  (v1.0.0)
    │   │   └── prompt_1762436504468DZZT93165V0E2H8N.md  (草稿)
    │   └── templates/                     # 1 个模版文件
    │       └── template_1762436504504JNZVWDGNNTM9D9T8.md
    └── backend/                            # 后端项目
        ├── prompts/                       # 2 个提示词文件
        │   ├── prompt_17624365045411X0GCG08558JQNVE.md  (v2.0.0)
        │   └── prompt_1762436504587WSKCMZXHFKTJ59PA.md  (v1.1.0)
        └── templates/                     # 1 个模版文件
            └── template_1762436504634S3RXC50J6PGPP3CV.md
```

---

## 🚀 快速开始

### 1. 生成测试数据

```bash
# 从项目根目录运行
python3 create_test_projects.py
```

**脚本功能**:
- ✅ 创建 3 个项目（default, frontend, backend）
- ✅ 生成 12 个提示词文件
- ✅ 生成 6 个模版文件
- ✅ 发布 5 个版本（带 Git 标签）
- ✅ 创建完整的索引文件
- ✅ 每个文件独立 Git 提交

**输出示例**:
```
🚀 开始创建测试项目数据...

📁 项目：default - 默认项目
  📄 提示词：代码审查助手
  ✅ Git commit: feat(default): add prompt 代码审查助手
  ✅ 发布版本：prompt/17624365042563BAHD83S771V4G3F/v1.0.0 (prod)
  ...

📇 更新索引...
✅ 索引已更新：12 个提示词，6 个模版

🎉 测试项目数据创建完成！
```

---

### 2. 验证数据完整性

```bash
# 运行验证脚本
./test_project_data.sh
```

**验证内容**:
- ✅ 目录结构完整性
- ✅ 文件数量正确
- ✅ 索引文件有效性
- ✅ Git 提交和标签
- ✅ Front Matter 格式
- ✅ 后端 API 响应（如果后端运行中）

**预期输出**:
```
📁 1. 检查目录结构
  ✓ PASS - repo_root 目录存在
  ✓ PASS - Git 仓库已初始化
  ✓ PASS - .promptmeta 目录存在
  ✓ PASS - projects 目录存在

📦 2. 检查项目目录
  ✓ PASS - default 项目存在
  ✓ PASS - frontend 项目存在
  ✓ PASS - backend 项目存在

...

✅ 所有测试通过！
```

---

### 3. 测试后端 API

```bash
# 确保后端已启动
python manage.py runserver

# 在新终端运行 API 测试
./test_api_with_projects.sh
```

**API 测试覆盖**:

#### 通用 API (`/v1/`)
- ✅ 健康检查 `/v1/health`
- ✅ 搜索提示词 `/v1/search?type=prompt`
- ✅ 按项目过滤 `/v1/search?project=default`
- ✅ 按标签过滤 `/v1/search?labels=开发`
- ✅ 按作者过滤 `/v1/search?author=admin`
- ✅ 索引状态 `/v1/index/status`

#### Simple API (`/v1/simple/`)
- ✅ 获取内容 `/v1/simple/prompts/{id}/content?ref=latest`
- ✅ 获取时间线 `/v1/simple/prompts/{id}/timeline?view=all`

#### Detail API (`/v1/detail/`)
- ✅ 获取历史 `/v1/detail/prompts/{id}/history`
- ✅ 获取发布 `/v1/detail/prompts/{id}/releases`
- ✅ 分支列表 `/v1/detail/git/branches`

**测试结果示例**:
```json
{
    "status": "healthy",
    "git": {
        "healthy": true,
        "branch": "92ab46f..."
    },
    "index": {
        "healthy": true,
        "prompts_count": 12,
        "templates_count": 6
    }
}
```

---

## 🔧 高级用法

### 查看 Git 历史

```bash
cd repo_root

# 查看提交历史
git log --oneline --all --graph

# 输出示例：
# 92ab46f chore: update index
# d01dedd feat(backend): add template GraphQL Schema 模版
# 7b673df feat(backend): add prompt 数据库 Schema 设计器
# ...
```

### 查看版本标签

```bash
cd repo_root

# 列出所有标签
git tag

# 输出示例：
# prompt/17624365042563BAHD83S771V4G3F/v1.0.0
# prompt/1762436504305RQA7K61S5QQRXZN9/v1.0.0
# prompt/17624365044222YX6MTA14HHQSZGQ/v1.0.0
# prompt/17624365045411X0GCG08558JQNVE/v2.0.0
# prompt/1762436504587WSKCMZXHFKTJ59PA/v1.1.0

# 查看标签详情
git show prompt/17624365042563BAHD83S771V4G3F/v1.0.0
```

### 查看索引内容

```bash
cat repo_root/.promptmeta/index.json | python3 -m json.tool

# 索引结构：
# {
#   "version": "1.0.0",
#   "updated_at": "2025-11-06T...",
#   "prompts": [...],      // 12 个提示词
#   "templates": [...]     // 6 个模版
# }
```

---

## 📖 文件格式说明

### 提示词/模版文件格式

```markdown
---
{
  "id": "17624365042563BAHD83S771V4G3F",
  "title": "代码审查助手",
  "slug": "code-review-assistant",
  "description": "帮助开发者进行代码审查，提供改进建议",
  "type": "prompt",
  "project": "default",
  "labels": ["开发", "代码审查", "最佳实践"],
  "author": "admin",
  "created_at": "2025-11-06T21:41:44.267287",
  "updated_at": "2025-11-06T21:41:44.267300",
  "version": "v1.0.0",
  "status": "draft"
}
---

# 代码审查助手

你是一个专业的代码审查专家...
```

**Front Matter 字段说明**:
- `id`: ULID 格式的唯一标识符
- `title`: 标题
- `slug`: URL 友好的标识符
- `description`: 描述
- `type`: 类型（prompt 或 template）
- `project`: 所属项目
- `labels`: 标签数组
- `author`: 作者
- `created_at`: 创建时间（ISO 8601）
- `updated_at`: 更新时间（ISO 8601）
- `version`: 版本号（语义版本）
- `status`: 状态（draft 或其他）
- `variables`: （仅模版）变量数组

---

## 🎯 使用场景

### 场景 1: 前端开发测试

```bash
# 1. 启动后端
python manage.py runserver

# 2. 启动前端（新终端）
./start-frontend.sh

# 3. 访问 http://localhost:3000
# 现在可以看到：
# - Dashboard 显示 12 个提示词、6 个模版
# - 3 个项目切换器
# - 按项目过滤功能
# - 已发布版本列表
```

### 场景 2: API 集成测试

```bash
# 测试搜索功能
curl "http://127.0.0.1:8000/v1/search?project=frontend&type=prompt" | python3 -m json.tool

# 测试获取内容
curl "http://127.0.0.1:8000/v1/simple/prompts/17624365044222YX6MTA14HHQSZGQ/content?ref=latest"

# 测试版本发布
curl "http://127.0.0.1:8000/v1/detail/prompts/17624365045411X0GCG08558JQNVE/releases" | python3 -m json.tool
```

### 场景 3: 数据迁移测试

```bash
# 备份现有数据
cp -r repo_root repo_root.backup

# 测试索引重建
curl -X POST http://127.0.0.1:8000/v1/index/rebuild

# 验证数据完整性
./test_project_data.sh
```

---

## 🔄 重新生成测试数据

如果需要从头开始生成全新的测试数据：

```bash
# 1. 备份现有数据（可选）
mv repo_root repo_root.old

# 2. 重新创建目录结构
mkdir -p repo_root/.promptmeta/schema
mkdir -p repo_root/projects/{default,frontend,backend}/{prompts,templates,chats}

# 3. 初始化 Git
cd repo_root && git init && cd ..

# 4. 运行生成脚本
python3 create_test_projects.py

# 5. 验证数据
./test_project_data.sh

# 6. 测试 API
./test_api_with_projects.sh
```

---

## 📊 数据统计

### 文件统计
- **总文件数**: 18 个
  - 12 个提示词文件 (`.md`)
  - 6 个模版文件 (`.md`)
  - 2 个对话历史文件 (`.json`) - 仅在 default 项目

### Git 统计
- **提交数**: 21 个
  - 每个文件一个独立提交
  - 1 个索引更新提交
- **标签数**: 8 个
  - 3 个旧版本标签 (v1.0.0)
  - 5 个新版本标签 (v1.0.0, v2.0.0, v1.1.0)

### 索引统计
- **索引条目**: 18 个
  - 12 个提示词索引
  - 6 个模版索引
- **索引大小**: ~9.5 KB

---

## ✅ 验证清单

生成测试数据后，请验证以下内容：

- [ ] `repo_root/.git` 目录存在
- [ ] `repo_root/.promptmeta/index.json` 包含 12 个提示词和 6 个模版
- [ ] `repo_root/projects/default/` 包含 8 个提示词、4 个模版
- [ ] `repo_root/projects/frontend/` 包含 2 个提示词、1 个模版
- [ ] `repo_root/projects/backend/` 包含 2 个提示词、1 个模版
- [ ] `git log` 显示 21 个提交
- [ ] `git tag` 显示 8 个标签
- [ ] 所有文件包含有效的 JSON Front Matter
- [ ] 健康检查 API 返回 200
- [ ] 搜索 API 正确过滤项目
- [ ] 前端可以正常显示所有项目数据

---

## 🐛 故障排除

### 问题 1: 脚本运行失败

```bash
# 检查 Python 版本
python3 --version  # 应该是 3.7+

# 检查工作目录
pwd  # 应该在 /Users/guoyuchen/Documents/Project/MyPromptManager

# 检查 Git 安装
git --version
```

### 问题 2: 索引文件不存在

```bash
# 手动重建索引
curl -X POST http://127.0.0.1:8000/v1/index/rebuild

# 或者重新运行生成脚本
python3 create_test_projects.py
```

### 问题 3: API 测试失败

```bash
# 检查后端是否运行
curl http://127.0.0.1:8000/v1/health

# 如果未运行，启动后端
python manage.py runserver

# 检查 repo_root 路径配置
cat config/settings.py | grep REPO_ROOT
```

### 问题 4: Git 配置错误

```bash
cd repo_root

# 检查 Git 配置
git config user.name
git config user.email

# 如果没有配置，手动设置
git config user.name "Test User"
git config user.email "test@example.com"
```

---

## 📚 相关文档

- [TEST_DATA_README.md](TEST_DATA_README.md) - 原始测试数据说明
- [README.md](../README.md) - 项目总览
- [CLAUDE.md](CLAUDE.md) - API 规范
- [LOCAL_SETUP.md](LOCAL_SETUP.md) - 本地使用配置
- [USAGE_EXAMPLES.md](USAGE_EXAMPLES.md) - 使用示例

---

## 📝 脚本文件

| 文件 | 功能 | 位置 |
|------|------|------|
| `create_test_projects.py` | 生成多项目测试数据 | 项目根目录 |
| `test_project_data.sh` | 验证数据完整性 | 项目根目录 |
| `test_api_with_projects.sh` | 测试后端 API | 项目根目录 |
| `generate_test_data.py` | 旧版测试数据生成器 | 项目根目录 |

---

**生成时间**: 2025-11-06
**版本**: 2.0.0
**状态**: ✅ 可用
**维护者**: MyPromptManager Team
